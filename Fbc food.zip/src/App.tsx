import { Suspense } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import { Toaster } from "@/components/ui/toaster";
import { useAuthStore } from "@/store/authStore";
import LoginPage from "@/pages/auth/LoginPage";
import CustomerDashboard from "@/pages/customer/CustomerDashboard";
import RestaurantMenuPage from "@/pages/customer/RestaurantMenuPage";
import CheckoutPage from "@/pages/customer/CheckoutPage";
import OrdersPage from "@/pages/customer/OrdersPage";
import OrderDetailPage from "@/pages/customer/OrderDetailPage";
import ProfilePage from "@/pages/customer/ProfilePage";
import RiderDashboard from "@/pages/rider/RiderDashboard";
import RiderOrderDetail from "@/pages/rider/RiderOrderDetail";
import RiderProfile from "@/pages/rider/RiderProfile";

function App() {
  const { isAuthenticated, user } = useAuthStore();

  // Redirect based on user role
  const getDefaultRoute = () => {
    if (!user) return '/login';
    switch (user.role) {
      case 'customer':
        return '/customer';
      case 'rider':
        return '/rider';
      case 'admin':
        return '/admin';
      default:
        return '/login';
    }
  };

  return (
    <>
      <Suspense fallback={
        <div className="min-h-screen flex items-center justify-center">
          <div className="animate-pulse text-lg font-display">Loading...</div>
        </div>
      }>
        <Routes>
          <Route path="/" element={
            isAuthenticated ? <Navigate to={getDefaultRoute()} replace /> : <LoginPage />
          } />
          <Route path="/login" element={<LoginPage />} />
          
          {/* Customer Routes */}
          <Route path="/customer" element={
            isAuthenticated ? <CustomerDashboard /> : <Navigate to="/login" replace />
          } />
          <Route path="/customer/restaurant/:restaurantId" element={
            isAuthenticated ? <RestaurantMenuPage /> : <Navigate to="/login" replace />
          } />
          <Route path="/customer/checkout" element={
            isAuthenticated ? <CheckoutPage /> : <Navigate to="/login" replace />
          } />
          <Route path="/customer/orders" element={
            isAuthenticated ? <OrdersPage /> : <Navigate to="/login" replace />
          } />
          <Route path="/customer/order/:orderId" element={
            isAuthenticated ? <OrderDetailPage /> : <Navigate to="/login" replace />
          } />
          <Route path="/customer/profile" element={
            isAuthenticated ? <ProfilePage /> : <Navigate to="/login" replace />
          } />

          {/* Rider Routes */}
          <Route path="/rider" element={
            isAuthenticated ? <RiderDashboard /> : <Navigate to="/login" replace />
          } />
          <Route path="/rider/order/:orderId" element={
            isAuthenticated ? <RiderOrderDetail /> : <Navigate to="/login" replace />
          } />
          <Route path="/rider/profile" element={
            isAuthenticated ? <RiderProfile /> : <Navigate to="/login" replace />
          } />
        </Routes>
      </Suspense>
      <Toaster />
    </>
  );
}

export default App;
