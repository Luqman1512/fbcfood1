import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, User, Mail, Phone, MapPin, LogOut, ChevronRight, Bell, Globe, CreditCard, HelpCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Separator } from '@/components/ui/separator';
import { useAuthStore } from '@/store/authStore';
import BottomNav from '@/components/customer/BottomNav';
import CartDrawer from '@/components/customer/CartDrawer';
import EditProfileModal from '@/components/customer/EditProfileModal';
import AddressModal from '@/components/customer/AddressModal';
import PaymentMethodModal from '@/components/customer/PaymentMethodModal';
import NotificationModal from '@/components/customer/NotificationModal';
import LanguageModal from '@/components/customer/LanguageModal';
import SupportModal from '@/components/customer/SupportModal';

export default function ProfilePage() {
  const navigate = useNavigate();
  const { user, logout } = useAuthStore();
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isEditProfileOpen, setIsEditProfileOpen] = useState(false);
  const [isAddressOpen, setIsAddressOpen] = useState(false);
  const [isPaymentOpen, setIsPaymentOpen] = useState(false);
  const [isNotificationOpen, setIsNotificationOpen] = useState(false);
  const [isLanguageOpen, setIsLanguageOpen] = useState(false);
  const [isSupportOpen, setIsSupportOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  if (!user) {
    return null;
  }

  const menuItems = [
    {
      icon: User,
      label: 'Edit Profile',
      onClick: () => setIsEditProfileOpen(true),
    },
    {
      icon: MapPin,
      label: 'Saved Addresses',
      onClick: () => setIsAddressOpen(true),
    },
    {
      icon: CreditCard,
      label: 'Payment Methods',
      onClick: () => setIsPaymentOpen(true),
    },
    {
      icon: Bell,
      label: 'Notifications',
      onClick: () => setIsNotificationOpen(true),
    },
    {
      icon: Globe,
      label: 'Language',
      subtitle: 'English',
      onClick: () => setIsLanguageOpen(true),
    },
    {
      icon: HelpCircle,
      label: 'Help & Support',
      onClick: () => setIsSupportOpen(true),
    },
  ];

  return (
    <div className="min-h-screen pb-20 bg-background">
      <div className="sticky top-0 z-40 bg-background/95 backdrop-blur border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={() => navigate('/customer')}
              className="md:hidden"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <h1 className="font-display text-2xl font-bold">Profile</h1>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6 max-w-2xl space-y-6">
        {/* Profile Header */}
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <Avatar className="h-20 w-20">
                <AvatarImage src={user.avatar} />
                <AvatarFallback className="bg-gradient-primary text-white text-2xl font-display">
                  {user.name.charAt(0).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <h2 className="font-display text-2xl font-bold">{user.name}</h2>
                <p className="text-sm text-muted-foreground">{user.email}</p>
                {user.phone && (
                  <p className="text-sm text-muted-foreground">{user.phone}</p>
                )}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Menu Items */}
        <Card>
          <CardContent className="p-0">
            {menuItems.map((item, index) => {
              const Icon = item.icon;
              return (
                <div key={index}>
                  <button
                    onClick={item.onClick}
                    className="w-full flex items-center gap-4 p-4 hover:bg-accent/50 transition-colors"
                  >
                    <Icon className="h-5 w-5 text-muted-foreground" />
                    <div className="flex-1 text-left">
                      <p className="font-medium">{item.label}</p>
                      {item.subtitle && (
                        <p className="text-sm text-muted-foreground">{item.subtitle}</p>
                      )}
                    </div>
                    <ChevronRight className="h-5 w-5 text-muted-foreground" />
                  </button>
                  {index < menuItems.length - 1 && <Separator />}
                </div>
              );
            })}
          </CardContent>
        </Card>

        {/* Logout Button */}
        <Button
          variant="outline"
          className="w-full text-destructive hover:text-destructive"
          onClick={handleLogout}
        >
          <LogOut className="h-4 w-4 mr-2" />
          Logout
        </Button>

        {/* App Info */}
        <div className="text-center text-sm text-muted-foreground space-y-1">
          <p>FBC Food v1.0.0</p>
          <p>© 2024 FBC Food. All rights reserved.</p>
        </div>
      </div>

      <BottomNav onCartClick={() => setIsCartOpen(true)} />
      <CartDrawer open={isCartOpen} onOpenChange={setIsCartOpen} />
      
      <EditProfileModal open={isEditProfileOpen} onOpenChange={setIsEditProfileOpen} />
      <AddressModal open={isAddressOpen} onOpenChange={setIsAddressOpen} />
      <PaymentMethodModal open={isPaymentOpen} onOpenChange={setIsPaymentOpen} />
      <NotificationModal open={isNotificationOpen} onOpenChange={setIsNotificationOpen} />
      <LanguageModal open={isLanguageOpen} onOpenChange={setIsLanguageOpen} />
      <SupportModal open={isSupportOpen} onOpenChange={setIsSupportOpen} />
    </div>
  );
}
