import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, MapPin, Phone, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Progress } from '@/components/ui/progress';
import { useOrderStore } from '@/store/orderStore';
import { cn } from '@/lib/utils';

export default function OrderDetailPage() {
  const { orderId } = useParams();
  const navigate = useNavigate();
  const order = useOrderStore((state) => state.getOrderById(orderId || ''));

  if (!order) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="font-display text-2xl font-bold mb-2">Order not found</h2>
          <Button onClick={() => navigate('/customer/orders')}>View Orders</Button>
        </div>
      </div>
    );
  }

  const statusSteps = [
    { key: 'pending', label: 'Order Placed', icon: '📝' },
    { key: 'preparing', label: 'Preparing', icon: '👨‍🍳' },
    { key: 'ready', label: 'Ready', icon: '✅' },
    { key: 'on_the_way', label: 'On the Way', icon: '🚗' },
    { key: 'delivered', label: 'Delivered', icon: '🎉' },
  ];

  const currentStepIndex = statusSteps.findIndex((s) => s.key === order.status);
  const progress = ((currentStepIndex + 1) / statusSteps.length) * 100;

  return (
    <div className="min-h-screen bg-background pb-8">
      <div className="sticky top-0 z-40 bg-background/95 backdrop-blur border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="font-display text-xl font-bold">Order Details</h1>
              <p className="text-xs text-muted-foreground">#{order.id}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6 max-w-2xl space-y-6">
        {/* Order Status Timeline */}
        <Card>
          <CardHeader>
            <CardTitle>Order Status</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <Progress value={progress} className="h-2" />
            
            <div className="space-y-4">
              {statusSteps.map((step, index) => {
                const isCompleted = index <= currentStepIndex;
                const isCurrent = index === currentStepIndex;
                
                return (
                  <div key={step.key} className="flex items-center gap-4">
                    <div
                      className={cn(
                        'w-10 h-10 rounded-full flex items-center justify-center text-lg transition-colors',
                        isCompleted
                          ? 'bg-gradient-primary text-white'
                          : 'bg-muted text-muted-foreground'
                      )}
                    >
                      {step.icon}
                    </div>
                    <div className="flex-1">
                      <p className={cn(
                        'font-semibold',
                        isCurrent && 'text-primary'
                      )}>
                        {step.label}
                      </p>
                      {isCurrent && order.estimatedDeliveryTime && (
                        <p className="text-xs text-muted-foreground">
                          ETA: {new Date(order.estimatedDeliveryTime).toLocaleTimeString('en-MY', {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </p>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Restaurant Info */}
        <Card>
          <CardHeader>
            <CardTitle>Restaurant</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4">
              <img
                src={order.restaurant.image}
                alt={order.restaurant.name}
                className="w-20 h-20 rounded-lg object-cover"
              />
              <div className="flex-1">
                <h3 className="font-semibold text-lg">{order.restaurant.name}</h3>
                <p className="text-sm text-muted-foreground mb-2">
                  {order.restaurant.cuisines.join(', ')}
                </p>
                <div className="flex items-center gap-1 text-sm">
                  <Star className="h-4 w-4 fill-current text-amber-600" />
                  <span className="font-semibold">{order.restaurant.rating}</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Delivery Address */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="h-5 w-5 text-primary" />
              Delivery Address
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-1">
              <p className="font-semibold">{order.deliveryAddress.label}</p>
              <p className="text-sm text-muted-foreground">
                {order.deliveryAddress.street}<br />
                {order.deliveryAddress.city}, {order.deliveryAddress.state}<br />
                {order.deliveryAddress.postalCode}
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Order Items */}
        <Card>
          <CardHeader>
            <CardTitle>Order Items</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {order.items.map((item, index) => (
              <div key={index} className="flex gap-3">
                <img
                  src={item.menuItem.image}
                  alt={item.menuItem.name}
                  className="w-16 h-16 rounded-lg object-cover"
                />
                <div className="flex-1">
                  <div className="flex justify-between">
                    <div>
                      <p className="font-semibold">{item.menuItem.name}</p>
                      <p className="text-sm text-muted-foreground">Qty: {item.quantity}</p>
                      {item.customizations.length > 0 && (
                        <p className="text-xs text-muted-foreground mt-1">
                          {item.customizations.map((c) => c.name).join(', ')}
                        </p>
                      )}
                    </div>
                    <p className="font-mono font-semibold">
                      RM {(item.menuItem.price * item.quantity).toFixed(2)}
                    </p>
                  </div>
                </div>
              </div>
            ))}

            <Separator />

            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Subtotal</span>
                <span className="font-mono">RM {order.subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Delivery Fee</span>
                <span className="font-mono">RM {order.deliveryFee.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Service Charge</span>
                <span className="font-mono">RM {order.serviceCharge.toFixed(2)}</span>
              </div>
              <Separator />
              <div className="flex justify-between text-lg font-semibold">
                <span>Total</span>
                <span className="font-mono">RM {order.total.toFixed(2)}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Payment Method */}
        <Card>
          <CardHeader>
            <CardTitle>Payment Method</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="capitalize">{order.paymentMethod.replace('_', ' ')}</p>
          </CardContent>
        </Card>

        {/* Actions */}
        {order.status === 'delivered' && !order.rating && (
          <Button className="w-full bg-gradient-primary hover:opacity-90">
            Rate Order
          </Button>
        )}

        <Button variant="outline" className="w-full" onClick={() => navigate('/customer')}>
          Order Again
        </Button>
      </div>
    </div>
  );
}
