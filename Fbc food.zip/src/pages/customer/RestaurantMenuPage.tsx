import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Star, Clock, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import MenuItemCard from '@/components/customer/MenuItemCard';
import MenuItemModal from '@/components/customer/MenuItemModal';
import BottomNav from '@/components/customer/BottomNav';
import CartDrawer from '@/components/customer/CartDrawer';
import { mockRestaurants, mockMenuItems } from '@/data/mockData';
import { MenuItem } from '@/types';

export default function RestaurantMenuPage() {
  const { restaurantId } = useParams();
  const navigate = useNavigate();
  const [selectedItem, setSelectedItem] = useState<MenuItem | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);

  const restaurant = mockRestaurants.find((r) => r.id === restaurantId);
  const menuItems = mockMenuItems[restaurantId || ''] || [];

  if (!restaurant) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Restaurant not found</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-20 bg-background">
      {/* Restaurant Header */}
      <div className="relative h-64 overflow-hidden">
        <img
          src={restaurant.image}
          alt={restaurant.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />
        
        <Button
          variant="ghost"
          size="icon"
          className="absolute top-4 left-4 bg-white/90 hover:bg-white"
          onClick={() => navigate(-1)}
        >
          <ArrowLeft className="h-5 w-5" />
        </Button>

        <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
          <h1 className="font-display text-3xl font-bold mb-2">{restaurant.name}</h1>
          <p className="text-white/90 mb-3">{restaurant.description}</p>
          
          <div className="flex flex-wrap gap-4 text-sm">
            <div className="flex items-center gap-1">
              <Star className="h-4 w-4 fill-current text-amber-400" />
              <span className="font-semibold">{restaurant.rating}</span>
              <span className="text-white/70">({restaurant.reviewCount})</span>
            </div>
            <div className="flex items-center gap-1 text-white/90">
              <Clock className="h-4 w-4" />
              <span>{restaurant.deliveryTime}</span>
            </div>
            <div className="flex items-center gap-1 text-white/90">
              <MapPin className="h-4 w-4" />
              <span>{restaurant.distance} km</span>
            </div>
          </div>
        </div>
      </div>

      {/* Menu Items */}
      <div className="container mx-auto px-4 py-6">
        <h2 className="font-display text-2xl font-bold mb-6">Menu</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {menuItems.map((item) => (
            <MenuItemCard
              key={item.id}
              item={item}
              onClick={() => setSelectedItem(item)}
            />
          ))}
        </div>

        {menuItems.length === 0 && (
          <div className="text-center py-16">
            <p className="text-muted-foreground">No menu items available</p>
          </div>
        )}
      </div>

      <MenuItemModal
        item={selectedItem}
        open={!!selectedItem}
        onOpenChange={(open) => !open && setSelectedItem(null)}
      />

      <BottomNav onCartClick={() => setIsCartOpen(true)} />
      <CartDrawer open={isCartOpen} onOpenChange={setIsCartOpen} />
    </div>
  );
}
