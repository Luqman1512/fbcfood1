import { useState } from 'react';
import { Search, SlidersHorizontal, MapPin } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import RestaurantCard from '@/components/customer/RestaurantCard';
import BottomNav from '@/components/customer/BottomNav';
import CartDrawer from '@/components/customer/CartDrawer';
import { mockRestaurants } from '@/data/mockData';
import { Restaurant } from '@/types';

export default function CustomerDashboard() {
  const [searchQuery, setSearchQuery] = useState('');
  const [restaurants] = useState<Restaurant[]>(mockRestaurants);
  const [isCartOpen, setIsCartOpen] = useState(false);

  const filteredRestaurants = restaurants.filter((restaurant) =>
    restaurant.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    restaurant.cuisines.some((cuisine) =>
      cuisine.toLowerCase().includes(searchQuery.toLowerCase())
    )
  );

  return (
    <div className="min-h-screen pb-20 bg-background">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-2 mb-4">
            <MapPin className="h-5 w-5 text-primary" />
            <div>
              <p className="text-sm font-semibold">Deliver to</p>
              <p className="text-xs text-muted-foreground">Jalan Ampang, Kuala Lumpur</p>
            </div>
          </div>

          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search restaurants or cuisines..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <Button variant="outline" size="icon">
              <SlidersHorizontal className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Hero Section */}
      <div className="container mx-auto px-4 py-8">
        <div className="relative h-48 rounded-2xl overflow-hidden mb-8 shadow-primary">
          <img
            src="https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=1200&q=80"
            alt="Hero"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-transparent flex items-center">
            <div className="px-8">
              <h2 className="font-display text-4xl font-bold text-white mb-2">
                Craving something?
              </h2>
              <p className="text-white/90 text-lg">
                Order from 1000+ restaurants
              </p>
            </div>
          </div>
        </div>

        {/* Restaurants Grid */}
        <div>
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-display text-2xl font-bold">
              {searchQuery ? 'Search Results' : 'Popular Restaurants'}
            </h3>
            <p className="text-sm text-muted-foreground">
              {filteredRestaurants.length} restaurants
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredRestaurants.map((restaurant) => (
              <RestaurantCard key={restaurant.id} restaurant={restaurant} />
            ))}
          </div>

          {filteredRestaurants.length === 0 && (
            <div className="text-center py-16">
              <p className="text-muted-foreground text-lg mb-2">No restaurants found</p>
              <p className="text-sm text-muted-foreground">Try adjusting your search</p>
            </div>
          )}
        </div>
      </div>

      <BottomNav onCartClick={() => setIsCartOpen(true)} />
      <CartDrawer open={isCartOpen} onOpenChange={setIsCartOpen} />
    </div>
  );
}
