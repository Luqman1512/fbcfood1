import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useAuthStore } from '@/store/authStore';
import { mockUsers } from '@/data/mockData';
import { Chrome } from 'lucide-react';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const login = useAuthStore((state) => state.login);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // Mock authentication
    const user = mockUsers.find((u) => u.email === email);
    if (user) {
      const mockToken = 'mock-jwt-token-' + user.id;
      login(user, mockToken);
      
      // Navigate based on role
      switch (user.role) {
        case 'customer':
          navigate('/customer');
          break;
        case 'rider':
          navigate('/rider');
          break;
        case 'admin':
          navigate('/admin');
          break;
      }
    } else {
      setError('Invalid email or password');
    }
  };

  const handleGoogleLogin = () => {
    // Mock Google OAuth - use customer account
    const user = mockUsers[0];
    const mockToken = 'mock-jwt-token-google-' + user.id;
    login(user, mockToken);
    navigate('/customer');
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-orange-50 via-background to-green-50">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="font-display text-5xl font-bold bg-gradient-primary bg-clip-text text-transparent mb-2">
            FBC Food
          </h1>
          <p className="text-muted-foreground">Delicious food, delivered fast</p>
        </div>

        <Card className="shadow-primary border-border/50">
          <CardHeader className="space-y-1">
            <CardTitle className="text-2xl font-display">Welcome back</CardTitle>
            <CardDescription>Sign in to your account to continue</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="you@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>
              {error && (
                <p className="text-sm text-destructive">{error}</p>
              )}
              <Button type="submit" className="w-full bg-gradient-primary hover:opacity-90 transition-opacity">
                Sign In
              </Button>
            </form>

            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <span className="w-full border-t" />
              </div>
              <div className="relative flex justify-center text-xs uppercase">
                <span className="bg-card px-2 text-muted-foreground">Or continue with</span>
              </div>
            </div>

            <Button
              type="button"
              variant="outline"
              className="w-full"
              onClick={handleGoogleLogin}
            >
              <Chrome className="mr-2 h-4 w-4" />
              Google
            </Button>

            <div className="text-sm text-center text-muted-foreground space-y-1">
              <p className="font-semibold">Demo Accounts:</p>
              <p>Customer: customer@fbcfood.com</p>
              <p>Rider: rider@fbcfood.com</p>
              <p>Admin: admin@fbcfood.com</p>
              <p className="text-xs">(Any password works)</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
