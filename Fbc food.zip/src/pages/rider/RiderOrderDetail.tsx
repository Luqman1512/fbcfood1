import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, MapPin, Phone, Navigation, CheckCircle, Package } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/components/ui/use-toast';

export default function RiderOrderDetail() {
  const navigate = useNavigate();
  const { orderId } = useParams();
  const { toast } = useToast();
  const [orderStatus, setOrderStatus] = useState<'accepted' | 'picked_up' | 'delivering'>('accepted');

  const order = {
    id: orderId,
    restaurant: {
      name: 'Nasi Kandar Pelita',
      address: '456 Jalan Raja Laut, Kuala Lumpur',
      phone: '+60 3-1234 5678',
      image: 'https://images.unsplash.com/photo-1596040033229-a0b13b1f8e1f?w=800&q=80',
    },
    customer: {
      name: 'Ahmad Abdullah',
      phone: '+60 12-345 6789',
      address: '123 Jalan Bukit Bintang, Kuala Lumpur, 55100',
      instructions: 'Ring the doorbell twice',
    },
    items: [
      { name: 'Nasi Kandar Special', quantity: 2, price: 12.50 },
      { name: 'Ayam Goreng', quantity: 1, price: 8.00 },
    ],
    total: 33.50,
    deliveryFee: 3.50,
    paymentMethod: 'Cash on Delivery',
  };

  const handlePickup = () => {
    setOrderStatus('picked_up');
    toast({
      title: 'Order Picked Up',
      description: 'Navigate to customer location',
    });
  };

  const handleComplete = () => {
    toast({
      title: 'Delivery Completed',
      description: 'Great job! Earnings updated.',
    });
    navigate('/rider');
  };

  const openMaps = (address: string) => {
    const encodedAddress = encodeURIComponent(address);
    window.open(`https://www.google.com/maps/search/?api=1&query=${encodedAddress}`, '_blank');
  };

  return (
    <div className="min-h-screen bg-background pb-6">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-background/95 backdrop-blur border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate('/rider')}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div className="flex-1">
              <h1 className="font-display text-2xl font-bold">Order #{orderId}</h1>
              <p className="text-sm text-muted-foreground">
                {orderStatus === 'accepted' && 'Pickup from restaurant'}
                {orderStatus === 'picked_up' && 'Deliver to customer'}
                {orderStatus === 'delivering' && 'On the way'}
              </p>
            </div>
            <Badge className="bg-green-500">RM {order.deliveryFee.toFixed(2)}</Badge>
          </div>
        </div>
      </div>

      <div className="container mx-auto max-w-2xl px-4 py-6 space-y-4">
        {/* Status Progress */}
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-full ${orderStatus === 'accepted' ? 'bg-primary text-white' : 'bg-green-500 text-white'}`}>
                  <Package className="h-5 w-5" />
                </div>
                <div>
                  <p className="font-semibold">Pickup Order</p>
                  <p className="text-sm text-muted-foreground">From restaurant</p>
                </div>
              </div>
              {orderStatus !== 'accepted' && <CheckCircle className="h-6 w-6 text-green-500" />}
            </div>

            <Separator className="my-4" />

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-full ${orderStatus === 'picked_up' || orderStatus === 'delivering' ? 'bg-primary text-white' : 'bg-muted text-muted-foreground'}`}>
                  <Navigation className="h-5 w-5" />
                </div>
                <div>
                  <p className="font-semibold">Deliver Order</p>
                  <p className="text-sm text-muted-foreground">To customer</p>
                </div>
              </div>
              {orderStatus === 'delivering' && <CheckCircle className="h-6 w-6 text-green-500" />}
            </div>
          </CardContent>
        </Card>

        {/* Restaurant Info */}
        {orderStatus === 'accepted' && (
          <Card>
            <CardContent className="p-6">
              <div className="flex items-start gap-4 mb-4">
                <img
                  src={order.restaurant.image}
                  alt={order.restaurant.name}
                  className="w-16 h-16 rounded-lg object-cover"
                />
                <div className="flex-1">
                  <h3 className="font-display text-lg font-semibold mb-1">
                    {order.restaurant.name}
                  </h3>
                  <div className="flex items-start gap-2 text-sm text-muted-foreground">
                    <MapPin className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span>{order.restaurant.address}</span>
                  </div>
                </div>
              </div>

              <div className="flex gap-2">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => window.open(`tel:${order.restaurant.phone}`)}
                >
                  <Phone className="h-4 w-4 mr-2" />
                  Call Restaurant
                </Button>
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => openMaps(order.restaurant.address)}
                >
                  <Navigation className="h-4 w-4 mr-2" />
                  Navigate
                </Button>
              </div>

              <Separator className="my-4" />

              <Button
                className="w-full bg-gradient-primary"
                size="lg"
                onClick={handlePickup}
              >
                Confirm Pickup
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Customer Info */}
        {(orderStatus === 'picked_up' || orderStatus === 'delivering') && (
          <Card>
            <CardContent className="p-6">
              <h3 className="font-semibold mb-4">Customer Details</h3>
              
              <div className="space-y-3 mb-4">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Name</p>
                  <p className="font-medium">{order.customer.name}</p>
                </div>

                <div>
                  <p className="text-sm text-muted-foreground mb-1">Delivery Address</p>
                  <p className="font-medium">{order.customer.address}</p>
                </div>

                {order.customer.instructions && (
                  <div className="bg-amber-50 border border-amber-200 p-3 rounded-lg">
                    <p className="text-sm font-medium text-amber-900 mb-1">Delivery Instructions</p>
                    <p className="text-sm text-amber-800">{order.customer.instructions}</p>
                  </div>
                )}
              </div>

              <div className="flex gap-2 mb-4">
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => window.open(`tel:${order.customer.phone}`)}
                >
                  <Phone className="h-4 w-4 mr-2" />
                  Call Customer
                </Button>
                <Button
                  variant="outline"
                  className="flex-1"
                  onClick={() => openMaps(order.customer.address)}
                >
                  <Navigation className="h-4 w-4 mr-2" />
                  Navigate
                </Button>
              </div>

              <Separator className="my-4" />

              <Button
                className="w-full bg-green-500 hover:bg-green-600"
                size="lg"
                onClick={handleComplete}
              >
                <CheckCircle className="h-5 w-5 mr-2" />
                Complete Delivery
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Order Items */}
        <Card>
          <CardContent className="p-6">
            <h3 className="font-semibold mb-4">Order Items</h3>
            <div className="space-y-3">
              {order.items.map((item, index) => (
                <div key={index} className="flex justify-between">
                  <div>
                    <p className="font-medium">{item.name}</p>
                    <p className="text-sm text-muted-foreground">Qty: {item.quantity}</p>
                  </div>
                  <p className="font-medium">RM {(item.price * item.quantity).toFixed(2)}</p>
                </div>
              ))}
            </div>

            <Separator className="my-4" />

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Subtotal</span>
                <span>RM {(order.total - order.deliveryFee).toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Delivery Fee</span>
                <span>RM {order.deliveryFee.toFixed(2)}</span>
              </div>
              <Separator />
              <div className="flex justify-between font-semibold">
                <span>Total</span>
                <span>RM {order.total.toFixed(2)}</span>
              </div>
              <div className="bg-muted/50 p-3 rounded-lg mt-2">
                <p className="text-sm font-medium">Payment Method</p>
                <p className="text-sm text-muted-foreground">{order.paymentMethod}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
