import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Package, DollarSign, Star, TrendingUp, MapPin, Clock, Phone } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useAuthStore } from '@/store/authStore';
import { Order } from '@/types';

export default function RiderDashboard() {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const [activeOrders] = useState<Order[]>([]);

  const stats = {
    todayEarnings: 125.50,
    todayDeliveries: 8,
    rating: 4.8,
    completionRate: 98,
  };

  const availableOrders: Order[] = [
    {
      id: '1',
      customerId: '1',
      restaurantId: '1',
      restaurant: {
        id: '1',
        name: 'Nasi Kandar Pelita',
        description: '',
        image: 'https://images.unsplash.com/photo-1596040033229-a0b13b1f8e1f?w=800&q=80',
        rating: 4.5,
        reviewCount: 120,
        deliveryTime: '25-35 min',
        deliveryFee: 3.50,
        cuisines: ['Malaysian'],
        priceRange: 2,
        distance: 1.2,
        isOpen: true,
      },
      items: [],
      subtotal: 28.50,
      deliveryFee: 3.50,
      serviceCharge: 1.50,
      total: 33.50,
      status: 'pending',
      deliveryAddress: {
        id: '1',
        label: 'Home',
        street: '123 Jalan Bukit Bintang',
        city: 'Kuala Lumpur',
        state: 'Wilayah Persekutuan',
        postalCode: '55100',
        lat: 3.1478,
        lng: 101.7013,
      },
      paymentMethod: 'cash',
      createdAt: new Date().toISOString(),
    },
  ];

  return (
    <div className="min-h-screen bg-background pb-6">
      {/* Header */}
      <div className="bg-gradient-primary text-white p-6">
        <div className="container mx-auto max-w-6xl">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-4">
              <Avatar className="h-16 w-16 border-2 border-white">
                <AvatarImage src={user?.avatar} />
                <AvatarFallback className="bg-white text-primary text-xl font-display">
                  {user?.name.charAt(0).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div>
                <h1 className="font-display text-2xl font-bold">{user?.name}</h1>
                <p className="text-white/90 text-sm">Rider ID: #{user?.id.slice(0, 8)}</p>
              </div>
            </div>
            <Button
              variant="outline"
              className="bg-white/10 border-white/20 text-white hover:bg-white/20"
              onClick={() => navigate('/rider/profile')}
            >
              Profile
            </Button>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-white/10 backdrop-blur rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <DollarSign className="h-5 w-5" />
                <span className="text-sm opacity-90">Today's Earnings</span>
              </div>
              <p className="font-display text-2xl font-bold">RM {stats.todayEarnings.toFixed(2)}</p>
            </div>

            <div className="bg-white/10 backdrop-blur rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <Package className="h-5 w-5" />
                <span className="text-sm opacity-90">Deliveries</span>
              </div>
              <p className="font-display text-2xl font-bold">{stats.todayDeliveries}</p>
            </div>

            <div className="bg-white/10 backdrop-blur rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <Star className="h-5 w-5" />
                <span className="text-sm opacity-90">Rating</span>
              </div>
              <p className="font-display text-2xl font-bold">{stats.rating}</p>
            </div>

            <div className="bg-white/10 backdrop-blur rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="h-5 w-5" />
                <span className="text-sm opacity-90">Completion</span>
              </div>
              <p className="font-display text-2xl font-bold">{stats.completionRate}%</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto max-w-6xl px-4 mt-6">
        <Tabs defaultValue="available" className="w-full">
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger value="available">
              Available Orders ({availableOrders.length})
            </TabsTrigger>
            <TabsTrigger value="active">
              Active Orders ({activeOrders.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="available" className="space-y-4">
            {availableOrders.length === 0 ? (
              <Card>
                <CardContent className="p-12 text-center">
                  <Package className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
                  <h3 className="font-display text-xl font-semibold mb-2">No Orders Available</h3>
                  <p className="text-muted-foreground">
                    New delivery requests will appear here
                  </p>
                </CardContent>
              </Card>
            ) : (
              availableOrders.map((order) => (
                <Card key={order.id} className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <img
                        src={order.restaurant.image}
                        alt={order.restaurant.name}
                        className="w-20 h-20 rounded-lg object-cover"
                      />
                      <div className="flex-1">
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <h3 className="font-display text-lg font-semibold">
                              {order.restaurant.name}
                            </h3>
                            <div className="flex items-center gap-2 text-sm text-muted-foreground">
                              <MapPin className="h-4 w-4" />
                              <span>{order.restaurant.distance} km away</span>
                            </div>
                          </div>
                          <Badge className="bg-green-500">
                            RM {order.deliveryFee.toFixed(2)}
                          </Badge>
                        </div>

                        <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
                          <div className="flex items-center gap-1">
                            <Clock className="h-4 w-4" />
                            <span>Pickup in 10 min</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Package className="h-4 w-4" />
                            <span>Order #{order.id}</span>
                          </div>
                        </div>

                        <div className="bg-muted/50 p-3 rounded-lg mb-4">
                          <p className="text-sm font-medium mb-1">Delivery Address:</p>
                          <p className="text-sm text-muted-foreground">
                            {order.deliveryAddress.street}, {order.deliveryAddress.city}
                          </p>
                        </div>

                        <div className="flex gap-2">
                          <Button
                            className="flex-1 bg-gradient-primary"
                            onClick={() => navigate(`/rider/order/${order.id}`)}
                          >
                            Accept Order
                          </Button>
                          <Button variant="outline" className="flex-1">
                            Decline
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </TabsContent>

          <TabsContent value="active" className="space-y-4">
            {activeOrders.length === 0 ? (
              <Card>
                <CardContent className="p-12 text-center">
                  <Package className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
                  <h3 className="font-display text-xl font-semibold mb-2">No Active Orders</h3>
                  <p className="text-muted-foreground">
                    Accept an order to start delivering
                  </p>
                </CardContent>
              </Card>
            ) : (
              activeOrders.map((order) => (
                <Card key={order.id}>
                  <CardContent className="p-6">
                    <p>Active order content here</p>
                  </CardContent>
                </Card>
              ))
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
