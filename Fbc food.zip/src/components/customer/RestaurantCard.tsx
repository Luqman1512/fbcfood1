import { useNavigate } from 'react-router-dom';
import { Star, Clock, DollarSign } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Restaurant } from '@/types';
import { cn } from '@/lib/utils';

interface RestaurantCardProps {
  restaurant: Restaurant;
}

export default function RestaurantCard({ restaurant }: RestaurantCardProps) {
  const navigate = useNavigate();

  return (
    <Card
      className="group cursor-pointer overflow-hidden border-border/50 hover:shadow-primary transition-all duration-300 hover:-translate-y-1"
      onClick={() => navigate(`/customer/restaurant/${restaurant.id}`)}
    >
      <div className="relative aspect-[16/9] overflow-hidden">
        <img
          src={restaurant.image}
          alt={restaurant.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
        {!restaurant.isOpen && (
          <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
            <span className="text-white font-semibold text-lg">Closed</span>
          </div>
        )}
      </div>

      <CardContent className="p-4 space-y-3">
        <div>
          <h3 className="font-display text-xl font-bold mb-1 line-clamp-1">
            {restaurant.name}
          </h3>
          <p className="text-sm text-muted-foreground line-clamp-2">
            {restaurant.description}
          </p>
        </div>

        <div className="flex flex-wrap gap-1.5">
          {restaurant.cuisines.slice(0, 3).map((cuisine) => (
            <Badge key={cuisine} variant="secondary" className="text-xs">
              {cuisine}
            </Badge>
          ))}
        </div>

        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center gap-1 text-amber-600">
            <Star className="h-4 w-4 fill-current" />
            <span className="font-semibold">{restaurant.rating}</span>
            <span className="text-muted-foreground">({restaurant.reviewCount})</span>
          </div>

          <div className="flex items-center gap-1 text-muted-foreground">
            <Clock className="h-4 w-4" />
            <span>{restaurant.deliveryTime}</span>
          </div>
        </div>

        <div className="flex items-center justify-between pt-2 border-t">
          <div className="flex items-center gap-1">
            {Array.from({ length: restaurant.priceRange }).map((_, i) => (
              <DollarSign key={i} className="h-3 w-3 text-primary" />
            ))}
            {Array.from({ length: 4 - restaurant.priceRange }).map((_, i) => (
              <DollarSign key={i} className="h-3 w-3 text-muted-foreground/30" />
            ))}
          </div>

          <div className="text-sm">
            <span className="text-muted-foreground">Delivery: </span>
            <span className="font-mono font-semibold">RM {restaurant.deliveryFee.toFixed(2)}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
