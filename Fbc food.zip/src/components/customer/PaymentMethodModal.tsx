import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { CreditCard, Wallet, Banknote, Plus, Check } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

interface PaymentMethodModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface PaymentMethod {
  id: string;
  type: 'card' | 'ewallet' | 'cash';
  name: string;
  details?: string;
  isDefault: boolean;
}

export default function PaymentMethodModal({ open, onOpenChange }: PaymentMethodModalProps) {
  const { toast } = useToast();
  const [methods, setMethods] = useState<PaymentMethod[]>([
    {
      id: '1',
      type: 'cash',
      name: 'Cash on Delivery',
      isDefault: true,
    },
    {
      id: '2',
      type: 'ewallet',
      name: 'Touch \'n Go eWallet',
      details: '012-345-6789',
      isDefault: false,
    },
  ]);

  const handleSetDefault = (id: string) => {
    setMethods(
      methods.map((method) => ({
        ...method,
        isDefault: method.id === id,
      }))
    );
    toast({
      title: 'Default Payment Updated',
      description: 'Your default payment method has been updated.',
    });
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'card':
        return CreditCard;
      case 'ewallet':
        return Wallet;
      case 'cash':
        return Banknote;
      default:
        return CreditCard;
    }
  };

  const getColor = (type: string) => {
    switch (type) {
      case 'card':
        return 'bg-blue-500/10 text-blue-600';
      case 'ewallet':
        return 'bg-purple-500/10 text-purple-600';
      case 'cash':
        return 'bg-green-500/10 text-green-600';
      default:
        return 'bg-gray-500/10 text-gray-600';
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-display text-2xl">Payment Methods</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <Button className="w-full bg-gradient-primary" disabled>
            <Plus className="h-4 w-4 mr-2" />
            Add Payment Method (Coming Soon)
          </Button>

          <div className="space-y-3">
            {methods.map((method) => {
              const Icon = getIcon(method.type);
              const colorClass = getColor(method.type);
              return (
                <Card
                  key={method.id}
                  className={`hover:shadow-md transition-shadow ${
                    method.isDefault ? 'ring-2 ring-primary' : ''
                  }`}
                >
                  <CardContent className="p-4">
                    <div className="flex items-center gap-3">
                      <div className={`p-3 rounded-lg ${colorClass}`}>
                        <Icon className="h-6 w-6" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold">{method.name}</h3>
                        {method.details && (
                          <p className="text-sm text-muted-foreground">{method.details}</p>
                        )}
                        {method.isDefault && (
                          <div className="flex items-center gap-1 mt-1">
                            <Check className="h-3 w-3 text-primary" />
                            <span className="text-xs text-primary font-medium">Default</span>
                          </div>
                        )}
                      </div>
                      {!method.isDefault && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleSetDefault(method.id)}
                        >
                          Set Default
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          <div className="bg-muted/50 p-4 rounded-lg">
            <p className="text-sm text-muted-foreground">
              <strong>Note:</strong> Card and e-wallet payments are coming soon. Currently, only
              Cash on Delivery is available.
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
