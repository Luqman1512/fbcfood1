import { useState, useEffect } from 'react';
import { Minus, Plus, X } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Checkbox } from '@/components/ui/checkbox';
import { Textarea } from '@/components/ui/textarea';
import { useCartStore } from '@/store/cartStore';
import { useToast } from '@/components/ui/use-toast';
import { MenuItem, SelectedCustomization } from '@/types';

interface MenuItemModalProps {
  item: MenuItem | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function MenuItemModal({ item, open, onOpenChange }: MenuItemModalProps) {
  const [quantity, setQuantity] = useState(1);
  const [selectedCustomizations, setSelectedCustomizations] = useState<SelectedCustomization[]>([]);
  const [specialInstructions, setSpecialInstructions] = useState('');
  const addItem = useCartStore((state) => state.addItem);
  const { toast } = useToast();

  useEffect(() => {
    if (open) {
      setQuantity(1);
      setSelectedCustomizations([]);
      setSpecialInstructions('');
    }
  }, [open]);

  if (!item) return null;

  const handleCustomizationChange = (
    customizationId: string,
    optionId: string,
    name: string,
    price: number,
    type: 'option' | 'addon'
  ) => {
    if (type === 'option') {
      // Radio button - replace existing selection for this customization
      setSelectedCustomizations((prev) => [
        ...prev.filter((c) => c.customizationId !== customizationId),
        { customizationId, optionId, name, price },
      ]);
    } else {
      // Checkbox - toggle
      setSelectedCustomizations((prev) => {
        const exists = prev.find(
          (c) => c.customizationId === customizationId && c.optionId === optionId
        );
        if (exists) {
          return prev.filter(
            (c) => !(c.customizationId === customizationId && c.optionId === optionId)
          );
        }
        return [...prev, { customizationId, optionId, name, price }];
      });
    }
  };

  const calculateTotal = () => {
    const basePrice = item.price;
    const customizationsPrice = selectedCustomizations.reduce((sum, c) => sum + c.price, 0);
    return (basePrice + customizationsPrice) * quantity;
  };

  const handleAddToCart = () => {
    // Validate required customizations
    const requiredCustomizations = item.customizations?.filter((c) => c.required) || [];
    for (const customization of requiredCustomizations) {
      const hasSelection = selectedCustomizations.some(
        (sc) => sc.customizationId === customization.id
      );
      if (!hasSelection) {
        toast({
          title: 'Required selection',
          description: `Please select ${customization.name}`,
          variant: 'destructive',
        });
        return;
      }
    }

    addItem(item, quantity, selectedCustomizations, specialInstructions);
    toast({
      title: 'Added to cart',
      description: `${quantity}x ${item.name}`,
    });
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="sr-only">{item.name}</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Image */}
          <div className="relative aspect-video rounded-lg overflow-hidden">
            <img
              src={item.image}
              alt={item.name}
              className="w-full h-full object-cover"
            />
          </div>

          {/* Item Info */}
          <div>
            <h2 className="font-display text-2xl font-bold mb-2">{item.name}</h2>
            <p className="text-muted-foreground mb-3">{item.description}</p>
            <p className="font-mono text-xl font-semibold text-primary">
              RM {item.price.toFixed(2)}
            </p>
          </div>

          {/* Customizations */}
          {item.customizations?.map((customization) => (
            <div key={customization.id} className="space-y-3">
              <div>
                <Label className="text-base font-semibold">
                  {customization.name}
                  {customization.required && (
                    <span className="text-destructive ml-1">*</span>
                  )}
                </Label>
              </div>

              {customization.type === 'option' ? (
                <RadioGroup
                  onValueChange={(value) => {
                    const option = customization.options.find((o) => o.id === value);
                    if (option) {
                      handleCustomizationChange(
                        customization.id,
                        option.id,
                        option.name,
                        option.price,
                        'option'
                      );
                    }
                  }}
                >
                  {customization.options.map((option) => (
                    <div key={option.id} className="flex items-center space-x-2">
                      <RadioGroupItem value={option.id} id={option.id} />
                      <Label htmlFor={option.id} className="flex-1 cursor-pointer">
                        {option.name}
                        {option.price > 0 && (
                          <span className="text-muted-foreground ml-2">
                            +RM {option.price.toFixed(2)}
                          </span>
                        )}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              ) : (
                <div className="space-y-2">
                  {customization.options.map((option) => (
                    <div key={option.id} className="flex items-center space-x-2">
                      <Checkbox
                        id={option.id}
                        checked={selectedCustomizations.some(
                          (sc) =>
                            sc.customizationId === customization.id &&
                            sc.optionId === option.id
                        )}
                        onCheckedChange={() =>
                          handleCustomizationChange(
                            customization.id,
                            option.id,
                            option.name,
                            option.price,
                            'addon'
                          )
                        }
                      />
                      <Label htmlFor={option.id} className="flex-1 cursor-pointer">
                        {option.name}
                        {option.price > 0 && (
                          <span className="text-muted-foreground ml-2">
                            +RM {option.price.toFixed(2)}
                          </span>
                        )}
                      </Label>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ))}

          {/* Special Instructions */}
          <div className="space-y-2">
            <Label htmlFor="instructions">Special Instructions (Optional)</Label>
            <Textarea
              id="instructions"
              placeholder="E.g., No onions, extra spicy..."
              value={specialInstructions}
              onChange={(e) => setSpecialInstructions(e.target.value)}
              rows={3}
            />
          </div>

          {/* Quantity and Add to Cart */}
          <div className="flex items-center gap-4 pt-4 border-t">
            <div className="flex items-center gap-3">
              <Button
                size="icon"
                variant="outline"
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
              >
                <Minus className="h-4 w-4" />
              </Button>
              <span className="font-semibold text-lg w-8 text-center">{quantity}</span>
              <Button
                size="icon"
                variant="outline"
                onClick={() => setQuantity(quantity + 1)}
              >
                <Plus className="h-4 w-4" />
              </Button>
            </div>

            <Button
              className="flex-1 bg-gradient-primary hover:opacity-90 transition-opacity"
              size="lg"
              onClick={handleAddToCart}
            >
              Add to Cart - RM {calculateTotal().toFixed(2)}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
