import { Home, Receipt, User, ShoppingBag } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useCartStore } from '@/store/cartStore';
import { cn } from '@/lib/utils';

interface BottomNavProps {
  onCartClick: () => void;
}

export default function BottomNav({ onCartClick }: BottomNavProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const itemCount = useCartStore((state) => state.getItemCount());

  const navItems = [
    { icon: Home, label: 'Home', path: '/customer' },
    { icon: Receipt, label: 'Orders', path: '/customer/orders' },
    { icon: User, label: 'Profile', path: '/customer/profile' },
  ];

  return (
    <>
      {/* Floating Cart Button */}
      {itemCount > 0 && (
        <div className="fixed bottom-20 right-4 z-50 md:bottom-4">
          <Button
            size="lg"
            className="rounded-full h-14 w-14 shadow-primary bg-gradient-primary hover:opacity-90 transition-opacity relative"
            onClick={onCartClick}
          >
            <ShoppingBag className="h-6 w-6" />
            <Badge className="absolute -top-1 -right-1 h-6 w-6 flex items-center justify-center p-0 bg-accent">
              {itemCount}
            </Badge>
          </Button>
        </div>
      )}

      {/* Bottom Navigation Bar */}
      <div className="fixed bottom-0 left-0 right-0 z-40 bg-card border-t md:hidden">
        <nav className="flex items-center justify-around h-16">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;

            return (
              <button
                key={item.path}
                onClick={() => navigate(item.path)}
                className={cn(
                  'flex flex-col items-center justify-center gap-1 flex-1 h-full transition-colors',
                  isActive ? 'text-primary' : 'text-muted-foreground'
                )}
              >
                <Icon className="h-5 w-5" />
                <span className="text-xs font-medium">{item.label}</span>
              </button>
            );
          })}
        </nav>
      </div>
    </>
  );
}
