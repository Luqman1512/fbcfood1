import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { MessageCircle, Mail, Phone, HelpCircle, ExternalLink } from 'lucide-react';

interface SupportModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function SupportModal({ open, onOpenChange }: SupportModalProps) {
  const supportOptions = [
    {
      icon: MessageCircle,
      title: 'Live Chat',
      description: 'Chat with our support team',
      action: 'Start Chat',
      color: 'bg-blue-500/10 text-blue-600',
    },
    {
      icon: Mail,
      title: 'Email Support',
      description: 'support@fbcfood.com',
      action: 'Send Email',
      color: 'bg-purple-500/10 text-purple-600',
    },
    {
      icon: Phone,
      title: 'Phone Support',
      description: '+60 3-1234 5678',
      action: 'Call Now',
      color: 'bg-green-500/10 text-green-600',
    },
    {
      icon: HelpCircle,
      title: 'FAQ & Help Center',
      description: 'Find answers to common questions',
      action: 'Visit Help Center',
      color: 'bg-orange-500/10 text-orange-600',
    },
  ];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px] max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-display text-2xl">Help & Support</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="bg-gradient-primary text-white p-4 rounded-lg">
            <h3 className="font-display text-lg font-semibold mb-2">Need Help?</h3>
            <p className="text-sm opacity-90">
              Our support team is available 24/7 to assist you with any questions or issues.
            </p>
          </div>

          <div className="space-y-3">
            {supportOptions.map((option, index) => {
              const Icon = option.icon;
              return (
                <Card key={index} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      <div className={`p-3 rounded-lg ${option.color}`}>
                        <Icon className="h-6 w-6" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold mb-1">{option.title}</h3>
                        <p className="text-sm text-muted-foreground mb-3">
                          {option.description}
                        </p>
                        <Button size="sm" variant="outline" className="w-full">
                          {option.action}
                          <ExternalLink className="h-3 w-3 ml-2" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          <div className="bg-muted/50 p-4 rounded-lg space-y-2">
            <h4 className="font-semibold text-sm">Quick Tips</h4>
            <ul className="text-sm text-muted-foreground space-y-1">
              <li>• Check your order status in the Orders tab</li>
              <li>• Contact your rider directly for delivery updates</li>
              <li>• Report issues within 24 hours for faster resolution</li>
            </ul>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
