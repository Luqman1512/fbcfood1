import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { MapPin, Plus, Trash2, Home, Briefcase, MapPinned } from 'lucide-react';
import { Address } from '@/types';
import { useToast } from '@/components/ui/use-toast';
import AddressFormModal from './AddressFormModal';

interface AddressModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function AddressModal({ open, onOpenChange }: AddressModalProps) {
  const { toast } = useToast();
  const [addresses, setAddresses] = useState<Address[]>([
    {
      id: '1',
      label: 'Home',
      street: '123 Jalan Bukit Bintang',
      city: 'Kuala Lumpur',
      state: 'Wilayah Persekutuan',
      postalCode: '55100',
      lat: 3.1478,
      lng: 101.7013,
      instructions: 'Ring the doorbell twice',
    },
  ]);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingAddress, setEditingAddress] = useState<Address | null>(null);

  const handleDelete = (id: string) => {
    setAddresses(addresses.filter((addr) => addr.id !== id));
    toast({
      title: 'Address Deleted',
      description: 'The address has been removed.',
    });
  };

  const handleEdit = (address: Address) => {
    setEditingAddress(address);
    setIsFormOpen(true);
  };

  const handleSave = (address: Address) => {
    if (editingAddress) {
      setAddresses(addresses.map((addr) => (addr.id === address.id ? address : addr)));
      toast({
        title: 'Address Updated',
        description: 'Your address has been updated successfully.',
      });
    } else {
      setAddresses([...addresses, { ...address, id: Date.now().toString() }]);
      toast({
        title: 'Address Added',
        description: 'New address has been added successfully.',
      });
    }
    setEditingAddress(null);
    setIsFormOpen(false);
  };

  const getIcon = (label: string) => {
    switch (label.toLowerCase()) {
      case 'home':
        return Home;
      case 'work':
      case 'office':
        return Briefcase;
      default:
        return MapPinned;
    }
  };

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="sm:max-w-[500px] max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-display text-2xl">Saved Addresses</DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <Button
              onClick={() => {
                setEditingAddress(null);
                setIsFormOpen(true);
              }}
              className="w-full bg-gradient-primary"
            >
              <Plus className="h-4 w-4 mr-2" />
              Add New Address
            </Button>

            {addresses.length === 0 ? (
              <div className="text-center py-12">
                <MapPin className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground">No saved addresses yet</p>
              </div>
            ) : (
              <div className="space-y-3">
                {addresses.map((address) => {
                  const Icon = getIcon(address.label);
                  return (
                    <Card key={address.id} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex items-start gap-3">
                          <div className="bg-primary/10 p-2 rounded-lg">
                            <Icon className="h-5 w-5 text-primary" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <h3 className="font-semibold mb-1">{address.label}</h3>
                            <p className="text-sm text-muted-foreground">
                              {address.street}, {address.city}
                            </p>
                            <p className="text-sm text-muted-foreground">
                              {address.state} {address.postalCode}
                            </p>
                            {address.instructions && (
                              <p className="text-xs text-muted-foreground mt-1 italic">
                                Note: {address.instructions}
                              </p>
                            )}
                          </div>
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => handleEdit(address)}
                            >
                              Edit
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => handleDelete(address.id)}
                              className="text-destructive hover:text-destructive"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      <AddressFormModal
        open={isFormOpen}
        onOpenChange={setIsFormOpen}
        address={editingAddress}
        onSave={handleSave}
      />
    </>
  );
}
