import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MenuItem } from '@/types';

interface MenuItemCardProps {
  item: MenuItem;
  onClick: () => void;
}

export default function MenuItemCard({ item, onClick }: MenuItemCardProps) {
  return (
    <Card
      className="group cursor-pointer overflow-hidden border-border/50 hover:shadow-primary transition-all duration-300 hover:-translate-y-0.5"
      onClick={onClick}
    >
      <div className="flex gap-4 p-4">
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2 mb-2">
            <h3 className="font-semibold text-lg line-clamp-2">{item.name}</h3>
            {!item.available && (
              <Badge variant="secondary" className="shrink-0">
                Unavailable
              </Badge>
            )}
          </div>
          <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
            {item.description}
          </p>
          <p className="font-mono font-semibold text-primary">
            RM {item.price.toFixed(2)}
          </p>
        </div>
        
        <div className="relative w-24 h-24 shrink-0 rounded-lg overflow-hidden">
          <img
            src={item.image}
            alt={item.name}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
          />
          {!item.available && (
            <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
              <span className="text-white text-xs font-semibold">Out</span>
            </div>
          )}
        </div>
      </div>
    </Card>
  );
}
