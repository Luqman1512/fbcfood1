import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Card, CardContent } from '@/components/ui/card';
import { Check } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

interface LanguageModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const languages = [
  { code: 'en', name: 'English', nativeName: 'English' },
  { code: 'ms', name: 'Bahasa Melayu', nativeName: 'Bahasa Melayu' },
];

export default function LanguageModal({ open, onOpenChange }: LanguageModalProps) {
  const { toast } = useToast();
  const [selectedLanguage, setSelectedLanguage] = useState('en');

  const handleSelectLanguage = (code: string) => {
    setSelectedLanguage(code);
    toast({
      title: 'Language Updated',
      description: `Language changed to ${languages.find((l) => l.code === code)?.name}`,
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[400px]">
        <DialogHeader>
          <DialogTitle className="font-display text-2xl">Select Language</DialogTitle>
        </DialogHeader>

        <div className="space-y-3">
          {languages.map((language) => (
            <Card
              key={language.code}
              className={`cursor-pointer hover:shadow-md transition-all ${
                selectedLanguage === language.code ? 'ring-2 ring-primary' : ''
              }`}
              onClick={() => handleSelectLanguage(language.code)}
            >
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-semibold">{language.name}</h3>
                    <p className="text-sm text-muted-foreground">{language.nativeName}</p>
                  </div>
                  {selectedLanguage === language.code && (
                    <div className="bg-primary text-white p-1 rounded-full">
                      <Check className="h-4 w-4" />
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="bg-muted/50 p-4 rounded-lg">
          <p className="text-sm text-muted-foreground">
            <strong>Note:</strong> Full translation support is coming soon. Currently, the app is
            available in English.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
