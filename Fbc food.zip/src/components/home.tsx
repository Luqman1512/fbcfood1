import { useNavigate } from 'react-router-dom';
import { ShoppingBag, Bike, Shield } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

function Home() {
  const navigate = useNavigate();

  const roles = [
    {
      icon: ShoppingBag,
      title: 'Customer',
      description: 'Order delicious food from your favorite restaurants',
      color: 'bg-orange-500/10 text-orange-600',
      path: '/login',
    },
    {
      icon: Bike,
      title: 'Rider',
      description: 'Deliver orders and earn money on your schedule',
      color: 'bg-blue-500/10 text-blue-600',
      path: '/login',
    },
    {
      icon: Shield,
      title: 'Admin',
      description: 'Manage restaurants, riders, and orders',
      color: 'bg-purple-500/10 text-purple-600',
      path: '/login',
    },
  ];

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-orange-50 via-background to-green-50">
      <div className="w-full max-w-4xl">
        <div className="text-center mb-12">
          <h1 className="font-display text-6xl font-bold bg-gradient-primary bg-clip-text text-transparent mb-4">
            FBC Food
          </h1>
          <p className="text-xl text-muted-foreground">
            Delicious food, delivered fast
          </p>
          <p className="text-muted-foreground mt-2">
            Choose your role to get started
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {roles.map((role) => {
            const Icon = role.icon;
            return (
              <Card
                key={role.title}
                className="hover:shadow-xl transition-all cursor-pointer group"
                onClick={() => navigate(role.path)}
              >
                <CardContent className="p-8 text-center">
                  <div className={`inline-flex p-6 rounded-2xl ${role.color} mb-6 group-hover:scale-110 transition-transform`}>
                    <Icon className="h-12 w-12" />
                  </div>
                  <h2 className="font-display text-2xl font-bold mb-3">
                    {role.title}
                  </h2>
                  <p className="text-muted-foreground mb-6">
                    {role.description}
                  </p>
                  <Button className="w-full bg-gradient-primary">
                    Continue as {role.title}
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="text-center mt-8 text-sm text-muted-foreground">
          <p>© 2024 FBC Food. All rights reserved.</p>
        </div>
      </div>
    </div>
  );
}

export default Home
