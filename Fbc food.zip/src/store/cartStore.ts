import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { CartItem, MenuItem, SelectedCustomization } from '@/types';

interface CartState {
  items: CartItem[];
  restaurantId: string | null;
  addItem: (
    menuItem: MenuItem,
    quantity: number,
    customizations: SelectedCustomization[],
    specialInstructions?: string
  ) => void;
  removeItem: (menuItemId: string) => void;
  updateQuantity: (menuItemId: string, quantity: number) => void;
  clearCart: () => void;
  getSubtotal: () => number;
  getItemCount: () => number;
}

export const useCartStore = create<CartState>()(
  persist(
    (set, get) => ({
      items: [],
      restaurantId: null,
      
      addItem: (menuItem, quantity, customizations, specialInstructions) => {
        const state = get();
        
        // Check if adding from different restaurant
        if (state.restaurantId && state.restaurantId !== menuItem.restaurantId) {
          // In production, show confirmation dialog
          set({ items: [], restaurantId: menuItem.restaurantId });
        }
        
        const existingItemIndex = state.items.findIndex(
          (item) => item.menuItem.id === menuItem.id
        );
        
        if (existingItemIndex >= 0) {
          const newItems = [...state.items];
          newItems[existingItemIndex].quantity += quantity;
          set({ items: newItems });
        } else {
          set({
            items: [
              ...state.items,
              { menuItem, quantity, customizations, specialInstructions },
            ],
            restaurantId: menuItem.restaurantId,
          });
        }
      },
      
      removeItem: (menuItemId) => {
        const newItems = get().items.filter(
          (item) => item.menuItem.id !== menuItemId
        );
        set({
          items: newItems,
          restaurantId: newItems.length > 0 ? get().restaurantId : null,
        });
      },
      
      updateQuantity: (menuItemId, quantity) => {
        if (quantity <= 0) {
          get().removeItem(menuItemId);
          return;
        }
        
        const newItems = get().items.map((item) =>
          item.menuItem.id === menuItemId ? { ...item, quantity } : item
        );
        set({ items: newItems });
      },
      
      clearCart: () => set({ items: [], restaurantId: null }),
      
      getSubtotal: () => {
        return get().items.reduce((total, item) => {
          const itemPrice = item.menuItem.price;
          const customizationsPrice = item.customizations.reduce(
            (sum, c) => sum + c.price,
            0
          );
          return total + (itemPrice + customizationsPrice) * item.quantity;
        }, 0);
      },
      
      getItemCount: () => {
        return get().items.reduce((total, item) => total + item.quantity, 0);
      },
    }),
    {
      name: 'fbc-cart-storage',
    }
  )
);
