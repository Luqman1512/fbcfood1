# FBC Food v1 - Food Delivery Platform

A production-grade food delivery web application and PWA designed for Malaysian users, offering a complete GrabFood/Foodpanda-like experience.

## 🚀 Features

### Customer Features
- ✅ Browse restaurants with filters (cuisine, price, rating)
- ✅ View restaurant menus with customization options
- ✅ Add items to cart with real-time updates
- ✅ Checkout with address and payment selection
- ✅ Track orders in real-time
- ✅ View order history
- ✅ **Profile Management**
  - Edit profile (name, email, phone, avatar)
  - Manage saved addresses
  - Payment methods
  - Notification settings
  - Language preferences (EN/BM)
  - Help & Support

### Rider Features
- ✅ **Rider Dashboard**
  - View available orders
  - Track daily earnings
  - View delivery statistics
  - Rating and completion rate
- ✅ **Order Management**
  - Accept/decline orders
  - View order details
  - Navigate to restaurant/customer
  - Confirm pickup and delivery
- ✅ **Rider Profile**
  - View earnings history
  - Performance metrics
  - Vehicle information

### Design System
- **Color Palette**: Warm orange-to-coral gradient with forest green accents
- **Typography**: Fraunces (display), Plus Jakarta Sans (body), JetBrains Mono (data)
- **Layout**: Mobile-first responsive design
- **Animations**: Smooth transitions and micro-interactions

## 🎨 Tech Stack

- **Framework**: React + TypeScript + Vite
- **Styling**: Tailwind CSS
- **UI Components**: ShadCN UI
- **State Management**: Zustand
- **Routing**: React Router
- **Icons**: Lucide React

## 📦 Installation

```bash
npm install
```

## 🏃‍♂️ Development

```bash
npm run dev
```

## 🔐 Demo Accounts

### Customer
- Email: `customer@fbcfood.com`
- Password: any

### Rider
- Email: `rider@fbcfood.com`
- Password: any

### Admin
- Email: `admin@fbcfood.com`
- Password: any

## 📱 Features Implemented

### ✅ Customer Profile Features
1. **Edit Profile** - Update name, email, phone, and avatar
2. **Saved Addresses** - Add, edit, and delete delivery addresses
3. **Payment Methods** - Manage payment options (Cash, e-wallet)
4. **Notifications** - Configure notification preferences
5. **Language** - Switch between English and Bahasa Melayu
6. **Support** - Access help center and contact support

### ✅ Rider UI/UX
1. **Dashboard** - View available and active orders
2. **Order Details** - Complete order information with navigation
3. **Profile** - Earnings, performance, and vehicle details
4. **Real-time Updates** - Order status tracking

## 🎯 User Flows

### Customer Flow
1. Login → Browse Restaurants → Select Restaurant
2. View Menu → Customize Items → Add to Cart
3. Checkout → Select Address & Payment → Place Order
4. Track Order → Rate & Review

### Rider Flow
1. Login → View Available Orders
2. Accept Order → Navigate to Restaurant
3. Confirm Pickup → Navigate to Customer
4. Complete Delivery → Update Earnings

## 🌟 Design Highlights

- **Modern Editorial meets Soft UI** design archetype
- **Gradient-based primary colors** for premium feel
- **Tinted shadows** for depth and warmth
- **Generous whitespace** for breathing room
- **Smooth animations** for delightful interactions
- **Mobile-first responsive** design

## 📂 Project Structure

```
src/
├── components/
│   ├── customer/       # Customer-specific components
│   │   ├── EditProfileModal.tsx
│   │   ├── AddressModal.tsx
│   │   ├── PaymentMethodModal.tsx
│   │   ├── NotificationModal.tsx
│   │   ├── LanguageModal.tsx
│   │   └── SupportModal.tsx
│   └── ui/            # Reusable UI components
├── pages/
│   ├── auth/          # Authentication pages
│   ├── customer/      # Customer pages
│   └── rider/         # Rider pages
├── store/             # Zustand state management
├── types/             # TypeScript type definitions
└── data/              # Mock data
```

## 🔧 Configuration

The app uses Vite with custom configuration for the Tempo platform:

```typescript
server: {
  allowedHosts: process.env.TEMPO === "true" ? true : undefined,
  host: process.env.TEMPO === "true" ? '0.0.0.0' : undefined,
}
```

## 🎨 Custom Styles

- **Gradient Primary**: `linear-gradient(135deg, #FF6B35 0%, #FF8C61 100%)`
- **Background**: Warm off-white `#FAF8F5`
- **Accent**: Deep forest green `#2D5F3F`
- **Subtle noise texture** for depth

## 📝 Notes

- All features are fully functional with mock data
- Real backend integration ready (Supabase/Convex)
- PWA features can be enabled
- Multi-language support structure in place

## 🚀 Future Enhancements

- Real-time order tracking with maps
- Push notifications
- Payment gateway integration
- Admin dashboard
- Analytics and reporting
- Multi-language full translation

## 📄 License

© 2024 FBC Food. All rights reserved.
